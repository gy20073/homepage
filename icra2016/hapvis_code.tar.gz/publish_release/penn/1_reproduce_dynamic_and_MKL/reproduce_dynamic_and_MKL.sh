#!/bin/bash
# script to train the HMM chains, both for reproducing the original result and my corrections. 

# configurations begin
SRC_BASE="../sub_code/"
BASE_DIR="./configuration_corrected/"
DATABASE_PATH="./configuration_corrected/database_corrected.hdf5"

# if reproducing the original results, comment out the above two lines, and use the following instead
#BASE_DIR="./configuration_original/"
#DATABASE_PATH="./configuration_original/database_original.hdf5"
WRONG_DATABASE_PATH="./configuration_original/database_original.hdf5"

PAR_JOBS="8"   # parallel level
PYTHON="/n/shokuji/dd/yangg/anaconda/bin/python"
# configuration ends

###########################dynamic features extraction##################################################
# train the HMM chains, this command write to BASE_DIR/chains
CMD=$PYTHON" "$SRC_BASE"train_chain_database.py "$DATABASE_PATH" "$BASE_DIR
$CMD  

# create the untrained classifiers, this command reads from the chains and write to untrained_adjectives folder in the BASE_DIR
CMD=$PYTHON" "$SRC_BASE"create_classifiers.py "$WRONG_DATABASE_PATH" "$BASE_DIR" "$PAR_JOBS
$CMD

# extract the dynamic features, this will write to adjective_phase_set subfolder in BASE_DIR
CMD=$PYTHON" "$SRC_BASE"create_hmm_features_v2.py "$WRONG_DATABASE_PATH" "$BASE_DIR
$CMD

############################The following test the MKL classifier##################################################
# make symbolic link to the original static features
rm -r ./static_features_original
ln -s ../penn_code/ml_data/mkl_unstandard_1_28/static/adjective_phase_set/ ./static_features_original

# first train the mkl classifiers, output the trained classifiers to "trained_adjectives"
CMD=$PYTHON" "$SRC_BASE"mkl_xvalidation.py "$BASE_DIR"adjective_phase_set ./static_features_original/ "$BASE_DIR
$CMD

# then merge the classifiers into a single pickle file
CMD=$PYTHON" yang_merge_clfs.py "$BASE_DIR"trained_adjectives/ "$BASE_DIR"all_clfs.pkl"
$CMD

# finally call the test script to test the merged classifier
CMD=$PYTHON" "$SRC_BASE"test_mkl_adjective_features.py "$BASE_DIR"all_clfs.pkl "$BASE_DIR"adjective_phase_set/ ./static_features_original/"
$CMD

