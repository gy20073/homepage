import pickle, sys, os

def merge_classifiers(idir, odir):
	clfs=[]
	for fn in os.listdir(idir):
		print fn
		clfs += [pickle.load(open(idir+fn, 'r'))]
	pickle.dump(clfs, open(odir,'w'))

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print "usage: %s trained_adjectives_dir merged_classifier_dir" % sys.argv[0]
        sys.exit(1)
    
    merge_classifiers(sys.argv[1], sys.argv[2])
    
