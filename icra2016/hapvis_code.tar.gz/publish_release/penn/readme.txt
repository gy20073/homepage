Instructions on my reproduction of the Penn's dynamic and static features

0. First download the penn's codebase from github: https://github.com/IanTheEngineer/Penn-haptics-bolt 
	rename the folder to penn_code  
	foler "sub_code" is my change of a subfolder of penn's code, mostly trying to avoid infinite loop and make the data readings more flexible. 
	The original version of "sub_code" folder could be found at:
		./penn_code/ros/haptics/bolt_haptic_learning/hadjective_hmm_classifier/src
1. reproduce the dynamic HMM features && train test MKL classifier
	(take the corrected reproduction as an example)
	download the raw signal database into ./configuration_corrected/database_corrected.hdf5
	make sure the configuration paths are properly set in "reproduce_dynamic_and_MKL.sh" and run it
	Note: this pipeline flows information in the order of:
		database_corrected.hdf5
		chains
		untrained_adjectives
		adjective_phase_set (i.e. the dynamic features)
		static_features_original (just a simple symlink of the available feature set)
		trained_adjectives (MKL trained classifiers)
		all_clfs.pkl
		[test result files]
		
2. extract the static and dynamic features (repartition of the train/test splits involved), 
and use them in the fuse pipeline, see ../multimodal/3_fusion/readme.txt for detail
	set the relavant flags in 2_Yang_extract_dynamic&static_features.ipynb and run it
	
