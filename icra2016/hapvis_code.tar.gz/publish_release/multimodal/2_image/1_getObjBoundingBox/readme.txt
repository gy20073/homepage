This folder convert full size images to object bounding boxes
	set the right paths in "conv_batch.m" and run it
