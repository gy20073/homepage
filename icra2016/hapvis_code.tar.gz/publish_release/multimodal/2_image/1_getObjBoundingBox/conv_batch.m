% convert full images to a texture part

src_dir='../../0_get_data/data/images_bak/';
dst_dir='../../0_get_data/data/images_whole/';
% if true, then small textures, otherwise, bigger object views.
isTexture=false; 

files=dir(src_dir);

for i=1:length(files)
    file=files(i).name;
    if length(file)>4 && strcmp(file(end-3:end), '.jpg') && file(1)~='.'
        file
        original=imread([src_dir file]);
        [x,y,w,h]=getObjBB(original,isTexture, 0);
        patch=original(y:y+h, x:x+w,:);
        imwrite(patch, [dst_dir file]);
    end
end
