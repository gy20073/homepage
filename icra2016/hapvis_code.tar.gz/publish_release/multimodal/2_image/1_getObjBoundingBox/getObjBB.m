% input is the original image
% output a bounding box in the original image
function [x, y, w, h]=getObjBB(original, small, verbose)
    close all
    %% resize to a lower resolution
    sz=512;
    im=imresize(original, [sz sz]);
    im_bak=im;
    if verbose
        figure,imshow(original);
    end

    %% find the plate and refine p
    % plate color and its tolerance
    p = [126.4300  103.3129  103.1158];
    toler = 8.3288;
    
    p=double(hsv(p));
    im=hsv(im);
    % iterate to refine p and the plate region
    for i=1:10
        pl=double(im);
        pl=pl-repmat(reshape(p, 1,1,3), sz, sz, 1);
        pl=sum(abs(pl), 3)/3;
        pl=pl<2*toler;
        if verbose
            if i==1
                figure
            end
            imshow(pl);
        end
        for j=1:3
            temp=im(:,:,j);
            p(j)=mean(temp(pl));
        end
    end
    %% find the object bounding box
    % design a circule convolutional filter (NO)
    % use canny filter to detect the edges of the center object. (NO)
    
    %find the biggest connected component
    [L, num] = bwlabel(pl,4);
    bestAll=0; bestI=0;
    for i=1:num
        now=sum(sum(L==i));
        if(now>bestAll)
            bestAll=now;
            bestI=i;
        end
    end
    pl=(L==bestI);
    if verbose
        figure,imshow(pl)
    end
    
    % (cx, cy) is the center, r is the radius
    [row, col]=find(pl);
    cy=median(row);
    left=quantile(col,0.01);
    right=quantile(col,0.99);
    cx=int32((left+right)/2);
    r=(right-left)/2;

    xratio=size(original,2)/sz;
    yratio=size(original,1)/sz;

    if small
        x=int32(cx-r/4)*xratio;
        y=int32(cy-1.25*r)*yratio;
        w=int32(r/2)*xratio;
        h=int32(r)*yratio;
    else
        x=int32(cx-r/2)*xratio;
        y=int32(cy-1.75*r)*yratio;
        w=int32(r)*xratio;
        h=int32(2*r)*yratio;
    end
    x=min(max(x, 1), size(original,2));
    y=min(max(y, 1), size(original,1));
    w=min(x+w, size(original,2))-x;
    h=min(y+h, size(original,1))-y;

    if verbose
        colors={'blue','green'};
        positions=int32([(cx-3)*xratio,(cy-3)*yratio,6*xratio,6*yratio;x, y, w, h]);
        labels={'center', 'bounding box'};
        J = insertObjectAnnotation(original, ...
            'rectangle',positions,labels,'Color',colors, 'LineWidth', 3);
        figure,imshow(J);
    end
end