function imp=hsv(im)
    isPoint=0;
    if ndims(im)<3
        im=reshape(im, 1,1,3);
        isPoint=1;
    end

    J=rgb2hsv(im);

    J(:,:,3)=1;
    J(:,:,1)=1;
    
    imp=uint8(255*hsv2rgb(J));
    
    if isPoint
        imp=imp(:);
    end
end
