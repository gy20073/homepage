This folder generates the CNN image features
1. Get the pretrained MINC model
	download the model at: http://opensurfaces.cs.cornell.edu/static/minc/minc-model.tar.gz
	rename the GoogleNet version of MINC's prototxt and pretrained weights as: "deploy.prototxt" and "minc.caffemodel"

2. set the related path in "extractVisionFeatures.ipynb" and run it
