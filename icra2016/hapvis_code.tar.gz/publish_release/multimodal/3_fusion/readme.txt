This part fuse the haptic and visual features
1. Test classification result of all configurations: haptic only, visual only and combined, as well as reproduce the baseline work: static, dynamic and combined
	set the paths in fuse_haptic_vision.ipynb and run it
	(You should run the penn/ pipeline before testing the old static and dynamic result)
2. Get sample predictions of some objects.
	sample_object_predictions.ipynb
3. the folder vis_auc_haptic_visual visualizes the AUC scores of haptic and visual pipeline
	run hapVSvis.m to get the plot. 
	The scores saved in the .m files are averaged in 3 different runs (different in the random train/test splits)
	The raw scores are saved in multiple_runs.xlsx
	
