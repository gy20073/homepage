#!/usr/bin/env sh
trainProtoName='./lstm.yangnet.train'

time ~/caffe-lstm-201509/build/tools/caffe train --solver=$trainProtoName -gpu 0 2> out.txt 

cat out.txt | grep "Test.*accuracy "

#cat out.txt | grep elapsed

