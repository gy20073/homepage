#!/usr/bin/env sh
trainProtoName='./concat2.yangnet.train'

time ~/caffe-201509/caffe/build/tools/caffe train --solver=$trainProtoName -gpu 0 2>out.txt 

cat out.txt | grep "Test.*accuracy "

#cat out.txt | grep elapsed

