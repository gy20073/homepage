function out=argmax(arr)
    assert(numel(arr)==2)
    if arr(1)>arr(2)
        out=0;
    else
        out=1;
    end
end