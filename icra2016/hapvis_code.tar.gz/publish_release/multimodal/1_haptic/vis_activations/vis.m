close all; clear; clc

% configurations start
load ana_vis_metallic
scale=[0 8]; % you could either set the scale to a fixed value
%scale='auto'; % or you could have automatic scale for each plot (but they won't be the same)

onlyRight=0;  % only show the right predicted instances
onlyPositive=0; % only show positive instances
% configurations end


for instanceI=(1:1)*1
    if mod(instanceI,1)==0
        isright=label(instanceI)==argmax(pre(instanceI,:));
        if onlyRight && (isright==0)
            continue
        end
        if onlyPositive && (label(instanceI)==0)
            continue
        end
        fprintf('for instance %d, true label is %d, prediction right: %d\n', ...
            instanceI, label(instanceI), isright);
        
    end
    pause(0.5)

    conv=squeeze(conv3(instanceI, :,:));

    % reshape the matrix into a correct form
    rsp=zeros(32, 5*4);
    for iep=1:4
        origin_col=(iep-1)*16+1: iep*16;
        target_col=(iep-1)*5+1:iep*5;
        rsp(1:16,target_col)=conv(origin_col, :);
        rsp(17:32, target_col)=conv(origin_col+64,:);
    end
    
    if ischar(scale)
        imagesc(rsp)
    else
        imagesc(rsp, scale)
    end
    
    colormap(flipud(hot))
    colorbar

    % row lines
    for iline=1:4
        line([0 21], [1 1]*iline*4+0.5, 'color', 'black')
    end

    % column lines
    for icol=1:3
        line([1 1]*5*icol+0.5, [0 33], 'color', 'black')
    end

    set(gca,'XTick',3:5:20,...                         %# Change the axes tick marks
            'XTickLabel',{'squeeze','hold','slow slide','fast slide'},...  %#   and tick labels
            'YTick',[2 6 10 14 24],...
            'YTickLabel',{'p_{ac}', 'p_{dc}', 't_{ac}', 't_{dc}', 'electrode'},...
            'YTickLabelRotation', 90,...
            'TickLength',[0 0],...
            'FontSize', 25);
end