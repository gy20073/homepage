To visualize the activations from the haptic convNet, you could follow the following procedures

1. Generate the activations (take adjective "compressible" as an example)
	run "allAdjs(3,3)" in ../haptic_feature_extraction.ipynb to get the trained network snapshot
	run visualize_haptic_conv3_activations.ipynb to get the activations
	You could skip this step, if using the saved .mat file "ana_vis_compressible"

2. run vis.m
