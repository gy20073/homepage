%% readin the data
easierFormat='../matlab_gen_data/easierFormat.mat';
trainH5='../data/data_conv/1train.h5';
% end of the configurations

load(easierFormat)
concat=h5read(trainH5, '/concat');
%%

% draw the raw signal
visOneFinger(raw(2,1,3).finger(1))

% draw the processed signal
sig4=squeeze(concat(1,:,9:12, 1));
sigE=squeeze(concat(1,:,25:28, 1));    
figure
visH5(sig4, sigE)

