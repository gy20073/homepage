Generate the signal visualization of haptic signals (both preprocessed and postprocessed)
	(require run the matlab_gen_data script)	
	run make_figures.m
