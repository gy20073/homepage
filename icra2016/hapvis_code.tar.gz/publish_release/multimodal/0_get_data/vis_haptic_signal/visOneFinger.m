function visOneFinger(fin)
    covs={'pac', 'pdc', 'tac', 'tdc', 'E'};
    colors={'r','g','b','c',''};
    labels={'p_{ac}', 'p_{dc}', 't_{ac}', 't_{dc}', 'Eletrode'};
    ncov=length(covs);
    for icov=1:ncov
        subplot(ncov,1, icov);
        var=fin.(covs{icov});
        plot(var', colors{icov});
        set(gca,'XLim',[0 length(var)+1], 'FontSize', 25)
        ylabel(labels{icov});
    end
    xlabel('Sample Indices')
end