The meaning of all the folders

data: folder that saves the processed train/test set for each adjective, usually a symlink of one of the data_conv, data_leave1out and data_lstm folders.

data_conv: the data folder used to feed in the haptic convNet pipeline.
data_leave1out: the data folder used to produce the sample prediction in the paper. I.e. predict all adjectives for a few objects. Thus the partition of the train/test set should be the same across adjectives. 
data_lstm: the lstm format that is converted from data_conv

images: the resized images (224*224) of image_bak
images_bak: original multiview photos of objects
images_texture: The center crop of the image that is small, i.e. revealing the texture details
images_whole: The center crop of the image that is of middle size, i.e. probably be the bounding box of the object.

index: the partition of the train/test set of the images. The partition should be the same as the partition of the haptic data in the "data" folder. Note that the index for each object has 100 entries and they're simply the repeat of 8 image views. Generally it's a symlink of either index_leave1out or index_rand17.
index_leave1out: the image index for "data_leave1out"
index_rand17: the image index for "data_conv" and "data_lstm" (those two use the same partition, because the latter is converted from the first one).

