% input the path of "easierFormat.mat", and get out the normalized & pca reduced & subsampled signal

function stdz=rawNormalize(easierFormatPath)
%%
    load(easierFormatPath)  % raw, objNames, phaseNames
%%
    % normalize
    % first calculate the average & sigma in training data for each covariate
    covs={'E','pac','pdc','tac','tdc'};
    % the statistic that is needed to calculate the aver and sigma
    % 1=sum, 2=sum of x^2, 3=count
    stat=zeros(4,5,3);
    % The minimal length of each variable in each Exploration Process
    minLen=zeros(4,5)+999999;
    maxLen=zeros(4,5);
    for obj=1:60
        for trail=1:10
            for ep=1:4
                for fig=1:2
                    cur=raw(obj, trail, ep).finger(fig);
                    for icov=1:5
                        stat(ep, icov, :)=updateHelper(stat(ep, icov, :), cur.(covs{icov}));
                        minLen(ep, icov)=min(minLen(ep, icov), length(cur.(covs{icov})));
                        maxLen(ep, icov)=max(maxLen(ep, icov), length(cur.(covs{icov})));
                    end
                end
            end
        end
    end
    aver=stat(:,:,1)./stat(:,:,3);
    sigma=sqrt(stat(:,:,2)./stat(:,:,3) - aver.^2);

    % second normalize all using this metric
    stdz=struct;
    for obj=1:60
        for trail=1:10
            for ep=1:4
                for fig=1:2
                    for icov=1:5
                        cur=raw(obj, trail, ep).finger(fig).(covs{icov});
                        subInter=1:minLen(ep,icov);
                        if ep==1
                            % if it's squeezing process, then subsample
                            % TODO(not perfect, a real length should be attached)
                            subInter=(1:minLen(ep,icov))*floor(length(cur)/minLen(ep,icov));
                        end
                        if icov==2
                            % downsample pac to 100 Hz
                            subInter=subInter(1:22:end);
                        end
                        stdz(obj, trail, ep).finger(fig).(covs{icov})=...
                           (double(cur(:,subInter))-aver(ep,icov))/sigma(ep,icov);
                    end
                end
            end
        end
    end

    % calculate the Epca field, Added to reduce 19 dimension E to 4 dimension
    for ep=1:4
        % a num*4*len reduced matrix
        pcaa=pcaE(stdz, ep);
        % assign back
        now=1;
        for iobj=1:60
            for itrail=1:10
                for fin=1:2
                    stdz(iobj,itrail, ep).finger(fin).Epca=reshape(pcaa(now, :,:), 4, numel(pcaa(now, :,:))/4 );
                    now=now+1;
                end
            end
        end

    end
end

% helper to update a covariate's sum, sum x^2, count
function new=updateHelper(old, matrix)
    matrix=double(matrix);
    new(1)=old(1)+sum(sum(matrix));
    new(2)=old(2)+sum(sum(matrix.^2));
    new(3)=old(3)+numel(matrix);
end

function out=pcaE(stdz, ep, dim)
    Es=getEs(stdz, ep);
    % Es is a num*19*len variable
    if nargin<3
        dim=4;
    end
    num=size(Es, 1);
    len=size(Es, 3);
    out=zeros(num, dim, len);
    for i=1:len
        pcaM=Es(:, :, i);
        coeff=pca(pcaM);
        out(:,:,i)=pcaM*coeff(:,1:dim);
    end
end

function Es=getEs(stdz, ep)
    Es=zeros(60*10*2, 19, size(stdz(1,1,ep).finger(1).E, 2));
    now=1;
    for iobj=1:60
        for itrail=1:10
            for fin=1:2
                Es(now, :,:)=stdz(iobj, itrail, ep).finger(fin).E;
                now=now+1;
            end
        end
    end
end

