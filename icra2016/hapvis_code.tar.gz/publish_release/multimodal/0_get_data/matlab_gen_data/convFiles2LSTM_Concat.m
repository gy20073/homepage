% a sample call would be 
% convFiles2LSTM_Concat('../data/data_conv/', '../data/data_lstm/')
function convFiles2LSTM_Concat(source_dir, target_dir)
    for i=1:25
        fprintf('converting iadj= %d\n', i)
        if i~=7
            convFilesConcatEachadj(i, source_dir, target_dir);
        end
    end
end

function convFilesConcatEachadj(iadj, source_dir, target_dir)
    selectOne=num2str(iadj);

    files={'train.h5', 'test.h5', 'validate.h5'};
    bufSize=100;

    for i=1:numel(files)
        ifname=strcat(source_dir, selectOne, files{i});
        
        ofname=strcat(target_dir, selectOne, files{i});
        delete(ofname)
        
        % detailed convertion
        var=h5read(ifname,'/concat');
        [out, cont]=blob2lstm(var, bufSize);
        toH5(ofname, '/lstm', out);
        toH5(ofname, '/cont', cont);

        % prepare and write label{i}
        seqLen=size(var, 2);
        label=h5read(ifname,'/label');
        inLabel=repmat(label, 1, seqLen, 1, 1);
        [outLabel, ~]=blob2lstm(inLabel, bufSize);
        toH5(ofname, '/label', outLabel);
    end
end

function toH5(filename, datasetname, outVar)
    sz=size(outVar);
    h5create(filename, datasetname, sz,...
            'Datatype', 'double', 'Deflate', 9, 'ChunkSize',sz);
    h5write(filename, datasetname, outVar);
end

function [out, cont]=blob2lstm(var, bufSize)
% input var is required to be (1, seqLen, Nchannels, numSeq)
% output out is (1, 1, Nchannels, numSeq*seqLen)
% bufSize is required to be a common divisor of the numSeq of all blobs

    seqLen=size(var, 2);
    numSeq=size(var, 4);
    numChn=size(var, 3);

    out=zeros(1,1,numChn,numSeq*seqLen);
    cont=zeros(1,1,1,numSeq*seqLen);
    for i=1:numSeq
        ngroup=floor((i-1)/bufSize);
        igroup=mod(i-1, bufSize);
        sPos=ngroup*(bufSize*seqLen)+igroup+1;
        ePos=sPos+bufSize*(seqLen-1);

        inter=sPos:bufSize:ePos;
        out(1,1,:,inter)=permute(var(1,:,:,i), [1 3 2 4]);
        
        cont(1,1,1,inter)=1;
        cont(1,1,1,sPos)=0;
    end
end
