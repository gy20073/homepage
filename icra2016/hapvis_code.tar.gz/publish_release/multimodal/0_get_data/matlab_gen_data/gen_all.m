% a call might be 
% gen_all('./easierFormat.mat', './labels_sorted.mat', '../data/data_conv/', '../data/images_bak/','../data/index_rand17/')
function gen_all(easierFormat_dir, label_dir, haptic_output_dir, IMAGE_BASE_DIR, INDEX_BASE_DIR)
	stdy=rawNormalize(easierFormat_dir)
	load(label_dir)

	% exclude those with less than 6 positives
	% exclusion=[2     5     7     8    10    11    21    24    25];
	exclusion=[7];

	rand('state',17);

	for iadj=1:25
		if isempty(find(iadj==exclusion))
			iadj
			filePrefix=strcat(haptic_output_dir, num2str(iadj));
			[testIds, validateIds]=splitWithLabelsCaffe(stdy, labels.data(:, iadj), filePrefix, 'test');
			genImageLists(testIds, validateIds, iadj, IMAGE_BASE_DIR, INDEX_BASE_DIR, label_dir)
		end
	end

end
