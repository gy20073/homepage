% a call might be 
% gen_all_leave1out('./easierFormat.mat', './labels_sorted.mat', '../data/data_leave1out/', '../data/images_bak/','../data/index_leave1out/', [26 37 44])
function gen_all_leave1out(easierFormat_dir, label_dir, haptic_output_dir, IMAGE_BASE_DIR, INDEX_BASE_DIR, testIds)
	stdy=rawNormalize(easierFormat_dir);
	load(label_dir)

    exclusion=[7];
    rand('state',17);

    for iadj=1:25
        if isempty(find(iadj==exclusion))
            iadj
            filePrefix=strcat(haptic_output_dir, num2str(iadj));
            
            simpleSP(stdy, labels.data(:, iadj), filePrefix, testIds);
			genImageLists(testIds, [], iadj, IMAGE_BASE_DIR, INDEX_BASE_DIR, label_dir)
        end
    end
end


function simpleSP(raw, label, filePrefix, testIds)
% label=labels.data(:,iadj);
% get the training, validation and testing files
% target=='test' split all data into test and train+validate
% target=='validate' split train+validate into train and validate
    
    % the 7 objects to be excluded
    n7=[1,26,29,32,41,42,46];
    n53=setdiff(1:60, n7);
    raw=raw(n53, :, :);
    label=label(n53);
    
    isTrain=ones(1, 53);
    isTrain(testIds)=0;
    isTrain=logical(isTrain);
    
    matToH5(raw(~isTrain,:,:), label(~isTrain), strcat(filePrefix,'test.h5'), true);
    matToH5(raw(isTrain,:,:), label(isTrain), strcat(filePrefix,'train.h5'), true);
end
