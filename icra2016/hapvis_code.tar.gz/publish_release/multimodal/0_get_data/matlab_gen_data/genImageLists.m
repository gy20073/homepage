% a valid value of IMAGE_BASE_DIR & INDEX_BASE_DIR might be 
% IMAGE_BASE_DIR='../data/images_bak/';
% INDEX_BASE_DIR='../data/index/';
function genImageLists(testIds, validateIds, iadj, IMAGE_BASE_DIR, INDEX_BASE_DIR, label_dir)

	% generate image list from the assigned testing and validation set
	oneSet(testIds, [INDEX_BASE_DIR num2str(iadj) 'test.txt'], iadj, IMAGE_BASE_DIR, label_dir);
	oneSet(validateIds, [INDEX_BASE_DIR num2str(iadj) 'validate.txt'], iadj, IMAGE_BASE_DIR, label_dir);
	
	trainIds=setdiff(1:53, testIds);
	trainIds=setdiff(trainIds, validateIds);

	oneSet(trainIds, [INDEX_BASE_DIR num2str(iadj) 'train.txt'], iadj, IMAGE_BASE_DIR, label_dir);
end

function oneSet(ids, name, iadj, IMAGE_BASE_DIR, label_dir)
	obj53={'aluminum_channel', 'applicator_pad', 'art_notebook', 'bath_cloth', ...
       'black_acrylic', 'black_eraser', 'black_foam', 'blue_sponge', ...
       'blue_toothpaste', 'brick', 'bubble_wrap', 'bumpy_foam', ...
       'caliper_case', 'charcoal_foam', 'cloth_sack', 'coco_liner', ...
       'colorful_book', 'concrete', 'cookie_box', 'corkboard', ...
       'cosmetics_box', 'cushioned_envelope', 'cutting_board', 'dishcloth', ...
       'flat_foam', 'furry_eraser', 'glass_container', 'gray_eraser', ... 
       'index_card_case', 'kitchen_sponge', 'koozie', 'layered_cork', ...
       'loofah', 'machined_plastic', 'notepad', 'orange_sponge', ...
       'placemat', 'plastic_case', 'plastic_dispenser', 'pool_noodle', ...
       'red_toothpaste', 'satin_pillowcase', 'sawed_plastic', ...
       'shelf_liner', 'silicone_block', 'soap_dispenser', 'steel_vase', ...
       'tarp', 'tissue_pack', 'toilet_paper', 'white_foam', 'yellow_felt',...
       'yellow_foam'};

	% 7 objects that are excluded
	n7=[1,26,29,32,41,42,46]; 
	load(label_dir)

	files=dir(IMAGE_BASE_DIR);
	fileID=fopen(name, 'w');

	for id=ids
		label=labels.data(setdiff(1:60, n7),iadj);
		% for each object, there's 100 haptic examples after ampflication
		% get a list of all images containing the object
		image_names=cell(1,8); 
		idx=1;

		for i=1:length(files)
			name=files(i).name;
			if strncmpi(name, obj53{id}, length(obj53{id})) && strcmp(name(end-6:end), '.h5.jpg') && (str2num(name(end-8:end-7)) <=8 )
				image_names{idx}=name;
				idx = idx + 1;
			end
		end

		for i=1:100
			fprintf(fileID, [IMAGE_BASE_DIR '%s %d\n'], image_names{mod(i, 8)+1}, label(id));
		end
	end	
	fclose(fileID);
end
