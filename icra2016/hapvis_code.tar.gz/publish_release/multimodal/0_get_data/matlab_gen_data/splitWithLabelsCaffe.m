function [testIds, validateIds]=splitWithLabelsCaffe(raw, label, filePrefix, task)
% label=labels.data(:,iadj);
% get the training, validation and testing files
% target=='test' split all data into test and train+validate
% target=='validate' split train+validate into train and validate
    
    if nargin<4
        task='test';
    end

    % because the images only has the following 53 objects, so we filter there
    obj53={'aluminum_channel', 'applicator_pad', 'art_notebook', 'bath_cloth', ...
       'black_acrylic', 'black_eraser', 'black_foam', 'blue_sponge', ...
       'blue_toothpaste', 'brick', 'bubble_wrap', 'bumpy_foam', ...
       'caliper_case', 'charcoal_foam', 'cloth_sack', 'coco_liner', ...
       'colorful_book', 'concrete', 'cookie_box', 'corkboard', ...
       'cosmetics_box', 'cushioned_envelope', 'cutting_board', 'dishcloth', ...
       'flat_foam', 'furry_eraser', 'glass_container', 'gray_eraser', ... 
       'index_card_case', 'kitchen_sponge', 'koozie', 'layered_cork', ...
       'loofah', 'machined_plastic', 'notepad', 'orange_sponge', ...
       'placemat', 'plastic_case', 'plastic_dispenser', 'pool_noodle', ...
       'red_toothpaste', 'satin_pillowcase', 'sawed_plastic', ...
       'shelf_liner', 'silicone_block', 'soap_dispenser', 'steel_vase', ...
       'tarp', 'tissue_pack', 'toilet_paper', 'white_foam', 'yellow_felt',...
       'yellow_foam'};
    % the 7 objects to be excluded
    n7=[1,26,29,32,41,42,46];
    n53=setdiff(1:60, n7);
    if strcmp(task, 'test')
        raw=raw(n53, :, :);
        label=label(n53);
    end

    % split procedure
    Nobj=size(raw,1);
    Npn=[sum(label), sum(1-label)];
    tNpn=ceil(0.1*Npn);

    isTrain=ones(1,Nobj);
    % for positive and negative
    for pn=0:1
        set=find(label==(1-pn));
        target=tNpn(pn+1);
        now=0;
        while now<target
            now=now+1;
            index=randi(length(set));
            index=set(index);
            set=setdiff(set, index);
            isTrain(index)=0;
        end
    end
    isTrain=logical(isTrain);
    
    % debug, Yang, change to no shuffle
    if strcmp(task, 'test')
        testIds=find(isTrain==0);
        matToH5(raw(~isTrain,:,:), label(~isTrain), strcat(filePrefix,'test.h5'), true);
        [~, validateIds]=splitWithLabelsCaffe(raw(isTrain,:,:), label(isTrain), filePrefix, 'validate');

        tvIds=setdiff(1:53, testIds);
        validateIds=tvIds(validateIds);
        
        disp('Test set: ')
        disp(obj53(testIds))
        disp('validate set: ')
        disp(obj53(validateIds))
        disp('Train set: ')
        disp(obj53(setdiff(tvIds, validateIds)))
    else 
        % split validate vs train
        testIds=[];
        validateIds=find(isTrain==0);
        matToH5(raw(~isTrain,:,:), label(~isTrain), strcat(filePrefix,'validate.h5'), true);
        matToH5(raw(isTrain,:,:), label(isTrain), strcat(filePrefix,'train.h5'), true);
    end

end
