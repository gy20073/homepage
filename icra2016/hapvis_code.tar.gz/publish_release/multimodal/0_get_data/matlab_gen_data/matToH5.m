function matToH5(raw, ilabels, filename, noshuffle)
% input the raw data for each object (might be less than 60 objs)
% the labels for each object
% output file name
    
    amplifyRatio=5; % amplify each training instance to 5 instances
    % Dimensions
    Nobj=size(raw, 1);
    
    numSeqs=Nobj*10*2*amplifyRatio;  % might be splited into more seqs, such as the two fingers
    
    blobs=cell(1,4); % input data blobs for EP{1-4}
    labels=zeros(1, 1, 1, numSeqs);
    covs={'pac','pdc','tac','tdc'}; %TODO(E is omitted now)
    ncov=length(covs);
    channels=ncov;

    % add support for E
    blobsE=cell(1,4);
    % add support for Epac
    blobsEpac=cell(1,4);
    
    for ep=1:4
        len=length(raw(1,1,ep).finger(1).pdc);
        len=floor(len/amplifyRatio);
        blob=zeros(numSeqs, channels, len, 1);
        iseq=0;

        % add support to E
        blobE=zeros(numSeqs, 19, len, 1);
        % add support to Epac
        blobEpac=zeros(numSeqs, 4, len, 1);
        
        for iobj=1:Nobj
            for trail=1:10
                % feature space layout: [fin1 * amplify(1-5)] [fin2 * amplify(1-5)]
                for fin=1:2
                    for iamp=1:amplifyRatio
                        
                        iseq=iseq+1;
                        labels(iseq)=ilabels(iobj);
                        subInter=iamp:amplifyRatio:(len*amplifyRatio);
                        for icov=1:ncov
                            cur=raw(iobj, trail, ep).finger(fin).(covs{icov});
                            blob(iseq, icov, :, 1)=cur(subInter);
                        end
                        % add support for E
                        blobE(iseq, :, :, 1)=raw(iobj, trail, ep).finger(fin).E(:, subInter);
                         % add support for Epac
                        blobEpac(iseq, :, :, 1)=raw(iobj, trail, ep).finger(fin).Epca(:, subInter);
                    end
                end
            end
        end
        blobs{ep}=blob;
        % support for E
        blobsE{ep}=blobE;
        % support for Epac
        blobsEpac{ep}=blobEpac;
    end
    
    delete(filename);
    if noshuffle
        shuffle=1:numSeqs;
    else
        shuffle=randperm(numSeqs);
    end

    % disable support for /e, because space consumption is too much and not quit useful
    %ArrBlobs={blobs, blobsE, blobsEpac};
    %prefixes={'/ep', '/e', '/epca'};
    ArrBlobs={blobs, blobsEpac};
    prefixes={'/ep', '/epca'};

    for ivar=1:2
        temp_blobs=ArrBlobs{ivar};
        prefix=prefixes{ivar};
        for ep=1:4
            blob=temp_blobs{ep};
            blob=permute(blob, [4 3 2 1]);
            blob=blob(:,:,:,shuffle);
            datasetname=strcat(prefix,num2str(ep));
            sz=size(blob); 
            
            h5create(filename, datasetname, sz,...
                'Datatype', 'double', 'Deflate', 1, 'ChunkSize',sz);
            h5write(filename, datasetname, blob);
        end
    end

    h5create(filename, '/label', size(labels),...
            'Datatype', 'double');
    h5write(filename, '/label', labels(1,1,1,shuffle));

    % add support to combined
    len_compressed=30;
    ArrCon=[blobs blobsEpac];
    concat=zeros(numSeqs, 4*8, len_compressed, 1);
    for i=0:7
        concat(:, i*4+1 : (i+1)*4, :, 1)=compressAVE(ArrCon{i+1}, len_compressed);
    end
    concat=permute(concat, [4 3 2 1]);
    concat=concat(:,:,:,shuffle);
    h5create(filename, '/concat', size(concat),...
            'Datatype', 'double');
    h5write(filename, '/concat', concat);
end

function out=compressAVE(blob, new_len)
    % blob is of size (num instance)*(4)*length*1
    old_len=size(blob, 3);
    inter=floor(old_len/new_len);
    ibase=inter:inter:old_len;
    ibase=ibase(1:new_len);

    out=-1;
    for i=(inter-1):-1:0
        nbase=ibase-i;
        if out==-1
            out=blob(:,:,nbase,1);
        else
            out=out+blob(:,:,nbase,:);
        end
    end
    out=out./inter;
end
