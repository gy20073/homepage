Readme for matlab code generating data

1. Input data
	easierFormat.mat: raw signals
	labels_sorted.mat: labels for each object and each adjective
	../data/images_bak: raw images of each object

2. generate the conv input files, call:
	>>gen_all('./easierFormat.mat', './labels_sorted.mat', '../data/data_conv/', '../data/images_bak/','../data/index_rand17/')
	outputs will be saved at:
		'../data/data_conv/': the haptic signals partitioned for each adjective
		'../data/index_rand17/': the same partition, but only index for the images

3. generate lstm format of the above conv files. Require the conv partition be generated before hand.
	>>convFiles2LSTM_Concat('../data/data_conv/', '../data/data_lstm/')
	The output will be saved at:
		'../data/data_lstm': the folder that saves LSTM format of the same data. It will uses the same index for images, say '../data/index_rand17/'.

4. generate the data for the intuitive analysis at Discussion.B in the paper
	>>gen_all_leave1out('./easierFormat.mat', './labels_sorted.mat', '../data/data_leave1out/', '../data/images_bak/','../data/index_leave1out/', [26 37 44])
	[26 37 44] are random objects that corresponds to ['furry_eraser', 'placemat', 'shelf_liner']
	The output will be saved in similar folders to (2).

Other .m files are tools to support the partition. See in-file explanation for details.

